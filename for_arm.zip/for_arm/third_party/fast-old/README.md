FAST corner detector by Edward Rosten.
The sourcefiles are from the CVD library: http://www.edwardrosten.com/cvd/
